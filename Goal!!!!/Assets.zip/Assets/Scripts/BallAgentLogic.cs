﻿using UnityEngine;
using Unity.MLAgents;
using Unity.MLAgents.Sensors;
using UnityEditor;

public class BallAgentLogic : Agent
{
    Rigidbody rBody;

    // Start is called before the first frame update
    void Start()
    {
        _ = GetComponent<Animation>();
        rBody = GetComponent<Rigidbody>();
    }

    // Update is called once per frame
    public Transform target;
    public override void OnEpisodeBegin()
    {
        // Reset agent(Agent location Vector3 & Agent velocity Vector3)
        this.rBody.angularVelocity = Vector3.zero;
        this.rBody.velocity = Vector3.zero;
        this.transform.localPosition = new Vector3(-9.5f, 0.5f, 0);

        // Move target to a new spot
        target.localPosition = new Vector3(8 + Random.value * 0.5f, 0.5f, Random.value * 6 + 3);
    }
    public override void CollectObservations(VectorSensor sensor)
    {
        // !!!Three critical vectors(9 observations in all) : Target and Agent positions & Agent velocity
        sensor.AddObservation(target.localPosition);
        sensor.AddObservation(this.transform.localPosition);
        sensor.AddObservation(rBody.velocity);
    }

    public float speed = 20;
    public override void OnActionReceived(float[] vectorAction)
    {
        Vector3 controlSignal = Vector3.zero;
        controlSignal.x = vectorAction[0] + 1;
       // controlSignal.x = controlSignal.x + 1;

        if (vectorAction[1] == 2)
        {
            controlSignal.z = 1;
        }
        else
        {
            controlSignal.z = - vectorAction[1];
            
        }

        // Adding forces before goal
        if (this.transform.localPosition.x < 8.5)
        {
            rBody.AddForce(controlSignal * speed);
        }

        float distanceToTarget = Vector3.Distance(this.transform.localPosition, target.localPosition);
        // Reached target
        if (distanceToTarget < 1.42f)
        {
            SetReward(1.0f);
            EndEpisode();
        }

        // Fell of platform
  //      if (this.transform.localPosition.z < -5.5 || this.transform.localPosition.z > 5.5)
        if (this.transform.localPosition.y < 0)
        {
            EndEpisode();
        }
    }
    public override void Heuristic(float[] actionsOut)
    {
        actionsOut[0] = Input.GetAxis("Vertical");
        actionsOut[1] = Input.GetAxis("Horizontal");
    }
}