﻿using System.Collections;
using System.Collections.Generic;
using UnityEditor;
using UnityEngine;

public class BallAgentFollow : MonoBehaviour
{
    public Transform BallAgentTransform;

    private Vector3 _CameraOffset;
    // Start is called before the first frame update
    void Start()
    {
        _ = GetComponent<Animation>();
        _CameraOffset = transform.position - BallAgentTransform.position;
    }

    // Update is called once per frame
    void LateUpdate()
    {
        transform.position = BallAgentTransform.position + _CameraOffset;
    }
}
